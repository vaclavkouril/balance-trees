#include "balance_trees/tree.hpp"

#include <algorithm>
#include <bit>
#include <iterator>
#include <stdexcept>
#include <utility>

namespace balance_trees {

RandomBits::RandomBits(std::string_view tape) : scripted_(true), tape_size_(tape.size()) {
    tape_.resize((tape.size() + 63) / 64);
    for (std::size_t i = 0; i < tape.size(); ++i) {
        if (tape[i] != '0' && tape[i] != '1') {
            throw std::invalid_argument("bit tape must contain only 0 and 1");
        }
        tape_[i / 64] |= std::uint64_t(tape[i] - '0') << (i % 64);
    }
}

unsigned RandomBits::bit() {
    if (scripted_ && count_ >= tape_size_) {
        throw std::out_of_range("bit tape exhausted");
    }
    if (remaining_ == 0) {
        if (scripted_) {
            buffer_ = tape_[count_ / 64];
        } else {
            // SplitMix64: fixed-width unsigned arithmetic defines wraparound.
            state_ += UINT64_C(0x9e3779b97f4a7c15);
            auto word = state_;
            word = (word ^ (word >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
            word = (word ^ (word >> 27)) * UINT64_C(0x94d049bb133111eb);
            buffer_ = word ^ (word >> 31);
        }
        remaining_ = 64;
    }
    unsigned result = buffer_ & 1;
    buffer_ >>= 1;
    --remaining_;
    ++count_;
    return result;
}

void BST::reserve(std::size_t count) {
    if (count > null) throw std::length_error("32-bit node index limit exceeded");
    keys_.reserve(count);
    left_.reserve(count);
    right_.reserve(count);
    parent_.reserve(count);
}

BST::InsertionPosition BST::insertion_position(Key key_value) const {
    Index ancestor = null, current = root_;
    std::uint32_t depth = 0;
    while (current != null) {
        if (key_value == keys_[current]) return {current, ancestor, depth};
        ancestor = current;
        current = key_value < keys_[current] ? left_[current] : right_[current];
        ++depth;
    }
    return {null, ancestor, depth};
}

void BST::attach_leaf(Index node, Index ancestor) {
    left_[node] = right_[node] = null;
    parent_[node] = ancestor;
    if (ancestor == null) root_ = node;
    else if (keys_[node] < keys_[ancestor]) left_[ancestor] = node;
    else right_[ancestor] = node;
}

InsertResult BST::insert(Key key_value) {
    const auto position = insertion_position(key_value);
    if (position.existing != null) return {position.existing, false, position.depth};
    if (size() == null) throw std::length_error("32-bit node index limit exceeded");
    // Reserve all arrays before changing their lengths, including on allocation
    // failure. Geometric growth avoids quadratic allocation without reserve().
    const auto capacity = std::min({keys_.capacity(), left_.capacity(),
                                    right_.capacity(), parent_.capacity()});
    if (size() == capacity) {
        reserve(std::min<std::size_t>(null, std::max<std::size_t>(8, size() * 2)));
    }
    const auto node = static_cast<Index>(size());
    keys_.push_back(key_value);
    left_.push_back(null);
    right_.push_back(null);
    parent_.push_back(null);
    attach_leaf(node, position.parent);
    return {node, true, position.depth};
}

bool BST::contains(Key key_value) const {
    return find(key_value) != null;
}

Index BST::find(Key key_value, std::uint64_t* visits) const {
    auto current = root_;
    while (current != null) {
        if (visits) ++*visits;
        if (key_value == keys_[current]) return current;
        current = key_value < keys_[current] ? left_[current] : right_[current];
    }
    return null;
}

Index BST::minimum(Index subtree, std::uint64_t* visits) const {
    if (subtree == null) return null;
    while (true) {
        if (visits) ++*visits;
        const auto child = left_.at(subtree);
        if (child == null) return subtree;
        subtree = child;
    }
}

Index BST::successor(Key key_value, std::uint64_t* visits) const {
    Index current = root_, candidate = null;
    while (current != null) {
        if (visits) ++*visits;
        if (keys_[current] > key_value) {
            candidate = current;
            current = left_[current];
        } else current = right_[current];
    }
    return candidate;
}

Index BST::detach(Index node, std::uint64_t* visits) {
    // Use the successor even for a node with only a right child. The proof's
    // transfer from the left gap relies on this particular removal rule.
    Index detached = node, child = left_.at(node);
    if (right_[node] != null) {
        detached = minimum(right_[node], visits);
        keys_[node] = keys_[detached];
        child = right_[detached];
    }
    const auto ancestor = parent_[detached];
    if (ancestor == null) root_ = child;
    else if (left_[ancestor] == detached) left_[ancestor] = child;
    else right_[ancestor] = child;
    if (child != null) parent_[child] = ancestor;
    left_[detached] = right_[detached] = parent_[detached] = null;
    return detached;
}

void BST::erase(Index node, std::uint64_t* visits) {
    const auto detached = detach(node, visits);
    const auto last = static_cast<Index>(size() - 1);
    // Keep all live nodes densely packed without a free list. Relocating the
    // last slot repairs only its parent and child links; topology is unchanged.
    if (detached != last) {
        keys_[detached] = keys_[last];
        left_[detached] = left_[last];
        right_[detached] = right_[last];
        parent_[detached] = parent_[last];
        const auto ancestor = parent_[detached];
        if (ancestor == null) root_ = detached;
        else if (left_[ancestor] == last) left_[ancestor] = detached;
        else right_[ancestor] = detached;
        if (left_[detached] != null) parent_[left_[detached]] = detached;
        if (right_[detached] != null) parent_[right_[detached]] = detached;
    }
    keys_.pop_back();
    left_.pop_back();
    right_.pop_back();
    parent_.pop_back();
}

InsertResult BST::reinsert(Index node, std::uint64_t* visits) {
    const auto saved_key = keys_.at(node);
    const auto detached = detach(node, visits);
    keys_[detached] = saved_key;
    const auto position = insertion_position(saved_key);
    if (visits) *visits += position.depth;
    attach_leaf(detached, position.parent);
    // The arrays retain their size during the temporary removal; no caller or
    // sampler observes that intermediate state. Repair sees the restored size.
    return {detached, true, position.depth};
}

bool BST::move_minimum_to_root(std::uint64_t* visits) {
    const auto node = minimum(root_, visits);
    if (node == root_) return false; // Includes an empty tree.
    const auto ancestor = parent_[node];
    left_[ancestor] = right_[node];
    if (right_[node] != null) parent_[right_[node]] = ancestor;
    right_[node] = root_;
    parent_[root_] = node;
    parent_[node] = null;
    root_ = node;
    return true;
}

void BST::rotate_up(Index node) {
    const auto ancestor = parent_.at(node);
    if (ancestor == null) throw std::invalid_argument("cannot rotate root");
    const auto grandparent = parent_[ancestor];
    if (grandparent != null && left_[grandparent] != ancestor && right_[grandparent] != ancestor)
        throw std::logic_error("inconsistent grandparent link");
    if (left_[ancestor] == node) {
        left_[ancestor] = right_[node];
        if (right_[node] != null) parent_[right_[node]] = ancestor;
        right_[node] = ancestor;
    } else if (right_[ancestor] == node) {
        right_[ancestor] = left_[node];
        if (left_[node] != null) parent_[left_[node]] = ancestor;
        left_[node] = ancestor;
    } else {
        throw std::logic_error("inconsistent parent link");
    }
    parent_[node] = grandparent;
    parent_[ancestor] = node;
    if (grandparent == null) root_ = node;
    else if (left_[grandparent] == ancestor) left_[grandparent] = node;
    else right_[grandparent] = node;
}

std::vector<std::uint32_t> BST::depths() const {
    struct Entry { Index node, parent, lower, upper; std::uint32_t depth; };
    std::vector<Entry> stack{{root_, null, null, null, 0}};
    std::vector<std::uint32_t> result(size());
    std::vector<bool> seen(size());
    std::size_t visited = 0;
    while (!stack.empty()) {
        auto entry = stack.back();
        stack.pop_back();
        auto node = entry.node;
        if (node == null) continue;
        if (node >= size() || seen[node]) throw std::logic_error("cycle or invalid child");
        seen[node] = true;
        ++visited;
        if (parent_[node] != entry.parent) throw std::logic_error("inconsistent parent link");
        if ((entry.lower != null && keys_[node] <= keys_[entry.lower]) ||
            (entry.upper != null && keys_[node] >= keys_[entry.upper]))
            throw std::logic_error("BST ordering violated");
        result[node] = entry.depth;
        stack.push_back({right_[node], node, node, entry.upper, entry.depth + 1});
        stack.push_back({left_[node], node, entry.lower, node, entry.depth + 1});
    }
    if (visited != size()) throw std::logic_error("unreachable node");
    return result;
}

std::size_t BST::storage_bytes() const {
    return keys_.capacity() * sizeof(Key) +
        (left_.capacity() + right_.capacity() + parent_.capacity()) * sizeof(Index);
}

void RebalanceContext::promote(Index node, std::uint32_t distance) {
    if (trace) stats.rotation_distances.push_back(distance);
    tree.rotate_up(node);
    ++stats.rotations;
}

std::uint32_t sample_target_depth(std::uint32_t node_count, RandomBits& bits) {
    if (node_count == 0) throw std::invalid_argument("node count must be positive");
    const auto levels = static_cast<unsigned>(std::bit_width(node_count - 1)) + 1;
    unsigned move = 0;
    while (move < levels && bits.bit() != 0) ++move;
    return move >= levels - 1 ? 0 : levels - move - 1;
}

namespace {
void repair_at_target(RebalanceContext& context, std::uint32_t target) {
    const auto depth = context.stats.insertion_depth;
    if (depth <= target) return;
    if (depth == target + 1) {
        context.promote(context.inserted, 0);
        return;
    }
    auto cursor = context.inserted;
    const auto distance = depth - target - 2;
    for (std::uint32_t step = 0; step < distance; ++step) {
        ++context.stats.visits;
        cursor = context.tree.parent(cursor);
    }
    ++context.stats.visits;
    const auto ancestor = context.tree.parent(cursor);
    const auto grandparent = context.tree.parent(ancestor);
    const bool straight = (context.tree.left(ancestor) == cursor) ==
                          (context.tree.left(grandparent) == ancestor);
    // Straight paths promote the parent once, unlike ordinary splay zig-zig.
    if (straight) context.promote(ancestor, distance + 1);
    else {
        context.promote(cursor, distance);
        context.promote(cursor, distance);
    }
}
} // namespace

void GeometricTargetLocalRepair::rebalance(RebalanceContext& context) {
    repair_at_target(context, sample_target_depth(
        static_cast<std::uint32_t>(context.tree.size()), context.bits));
}

std::uint32_t maximum_three_quarters_target_depth(std::uint32_t node_count) {
    if (node_count == 0) throw std::invalid_argument("node count must be positive");
    // floor((4/3)^k), computed with exact integer arithmetic, through UINT32_MAX.
    static constexpr std::uint64_t thresholds[] = {
        1ULL, 1ULL, 1ULL, 2ULL, 3ULL, 4ULL,
        5ULL, 7ULL, 9ULL, 13ULL, 17ULL, 23ULL,
        31ULL, 42ULL, 56ULL, 74ULL, 99ULL, 133ULL,
        177ULL, 236ULL, 315ULL, 420ULL, 560ULL, 747ULL,
        996ULL, 1328ULL, 1771ULL, 2362ULL, 3149ULL, 4199ULL,
        5599ULL, 7466ULL, 9954ULL, 13273ULL, 17697ULL, 23596ULL,
        31462ULL, 41950ULL, 55933ULL, 74577ULL, 99437ULL, 132583ULL,
        176777ULL, 235703ULL, 314271ULL, 419028ULL, 558704ULL, 744938ULL,
        993251ULL, 1324335ULL, 1765780ULL, 2354374ULL, 3139166ULL, 4185554ULL,
        5580739ULL, 7440986ULL, 9921315ULL, 13228420ULL, 17637893ULL, 23517191ULL,
        31356255ULL, 41808340ULL, 55744454ULL, 74325939ULL, 99101252ULL, 132135003ULL,
        176180004ULL, 234906672ULL, 313208896ULL, 417611861ULL, 556815815ULL, 742421087ULL,
        989894783ULL, 1319859711ULL, 1759812949ULL, 2346417265ULL, 3128556353ULL, 4171408471ULL,
        5561877962ULL,
    };
    return static_cast<std::uint32_t>(
        std::lower_bound(std::begin(thresholds), std::end(thresholds), node_count)
        - std::begin(thresholds));
}

std::uint32_t sample_three_quarters_target_depth(std::uint32_t node_count, RandomBits& bits) {
    auto target = maximum_three_quarters_target_depth(node_count);
    while (target > 0) {
        const auto first = bits.bit();
        const auto second = bits.bit();
        if (first == 0 && second == 0) break;
        --target;
    }
    return target;
}

void GeometricThreeQuarters::rebalance(RebalanceContext& context) {
    repair_at_target(context, sample_three_quarters_target_depth(
        static_cast<std::uint32_t>(context.tree.size()), context.bits));
}

StrategyFactory::StrategyFactory() {
    register_strategy("geometric-target-local-repair", [] {
        return std::make_unique<GeometricTargetLocalRepair>();
    });
    register_strategy("geometric-three-quarters", [] {
        return std::make_unique<GeometricThreeQuarters>();
    });
    register_strategy("geometric-full-bst", [] {
        return std::make_unique<GeometricFullBST>();
    });
    register_strategy("none", [] { return std::make_unique<NoRebalance>(); });
}

void StrategyFactory::register_strategy(std::string name, Creator creator) {
    if (name.empty() || !creator || creators_.contains(name))
        throw std::invalid_argument("empty or duplicate strategy registration");
    creators_.emplace(std::move(name), std::move(creator));
}

std::unique_ptr<Strategy> StrategyFactory::create(const std::string& name) const {
    const auto found = creators_.find(name);
    if (found == creators_.end()) throw std::invalid_argument("unknown strategy: " + name);
    auto strategy = found->second();
    if (!strategy) throw std::invalid_argument("strategy creator returned null");
    return strategy;
}

TreeFlavor::TreeFlavor(std::unique_ptr<Strategy> strategy, RandomBits bits, bool trace)
    : strategy_(std::move(strategy)), bits_(std::move(bits)), trace_(trace) {
    if (!strategy_) throw std::invalid_argument("strategy must not be null");
}

InsertionStats TreeFlavor::insert(Key key_value) {
    return repair(tree_.insert(key_value));
}

InsertionStats TreeFlavor::repair(InsertResult result) {
    InsertionStats stats{result.inserted, result.depth, 0, 0, 0, {}};
    if (result.inserted) {
        const auto before = bits_.count();
        RebalanceContext context{tree_, result.node, bits_, stats, trace_};
        strategy_->rebalance(context);
        stats.random_bits = bits_.count() - before;
    }
    return stats;
}

DeletionStats TreeFlavor::erase(Key key_value) {
    if (!strategy_->supports_deletion())
        throw std::logic_error("deletion requires the geometric-full-bst strategy");
    DeletionStats stats;
    const auto node = tree_.find(key_value, &stats.search_visits);
    if (node == null) return stats;
    tree_.erase(node, &stats.search_visits);
    stats.erased = true;
    if (tree_.size() == 0) {
        cursor_.reset();
        return stats;
    }
    refresh_next(stats);
    refresh_next(stats);
    return stats;
}

void TreeFlavor::refresh_next(DeletionStats& stats) {
    auto node = cursor_ ? tree_.successor(*cursor_, &stats.search_visits)
                        : tree_.minimum(tree_.root(), &stats.search_visits);
    if (node == null) {
        stats.minimum_moves += tree_.move_minimum_to_root(&stats.search_visits);
        node = tree_.root();
    }
    const auto refreshed_key = tree_.key(node);
    const auto insertion = repair(tree_.reinsert(node, &stats.search_visits));
    stats.visits += insertion.visits;
    stats.rotations += insertion.rotations;
    stats.random_bits += insertion.random_bits;
    ++stats.refreshes;
    if (trace_) {
        stats.refreshed_keys.push_back(refreshed_key);
        stats.rotation_distances.insert(stats.rotation_distances.end(),
            insertion.rotation_distances.begin(), insertion.rotation_distances.end());
    }
    // Save a value, never a node index: successor copying and storage
    // compaction can relocate keys, and the cursor key may later be deleted.
    cursor_ = refreshed_key;
}

} // namespace balance_trees
