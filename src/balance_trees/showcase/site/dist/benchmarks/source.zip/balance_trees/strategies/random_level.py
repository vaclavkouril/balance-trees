"""Perfect-tree leaf promotion and the archived interval-based promotion policy."""

from dataclasses import dataclass

from .base import RebalanceContext
from .perfect_tree_target import sample_perfect_tree_depth

PRIORITY_BITS = 64


@dataclass(slots=True)
class RandomLevel:
    """Promote the inserted leaf to a sampled perfect-tree depth, if deeper.

    Sample uniformly over vertices of the smallest perfect tree containing
    n vertices, where n includes the new leaf. Every rotation promotes the
    inserted vertex; no rotation is needed when its depth is <= the target.
    Unlike local repair, a deep leaf may require more than two rotations.
    """

    inserted_count: int = 0

    def rebalance(self, context: RebalanceContext) -> None:
        self.inserted_count += 1
        target_depth = sample_perfect_tree_depth(self.inserted_count, context.bits)
        for _ in range(max(0, context.stats.insertion_depth - target_depth)):
            context.promote(context.inserted, distance=0)


@dataclass(slots=True)
class TreapPriority:
    """Roll a priority, then promote the leaf only if its target is shallower.

    Priorities are not stored on nodes. The strategy retains only the number
    of inserted nodes and the lowest/highest priorities observed so far.
    """

    inserted_count: int = 0
    lowest_priority: int | None = None
    highest_priority: int | None = None

    def roll_priority(self, context: RebalanceContext) -> int:
        value = 0
        for _ in range(PRIORITY_BITS):
            value = (value << 1) | context.bits.bit()
        return value

    def target_depth(
        self,
        priority: int,
        lowest: int,
        highest: int,
        node_count: int,
        insertion_depth: int,
    ) -> int:
        """Choose the depth implied by the priority in the observed interval."""
        if priority < lowest:
            return 0

        if priority > highest:
            # Outside the known range: leave the new leaf where BST insertion put it.
            return insertion_depth

        if highest == lowest:
            return 0

        # Smallest number of levels whose perfect tree can hold node_count nodes:
        # 1 + 2 + ... + 2**(levels - 1) >= node_count.
        levels = max(1, node_count.bit_length())

        # Divide [lowest, highest] into bands whose widths are proportional to
        # 1, 2, 4, ..., matching a perfect binary tree's level capacities.
        total_weight = (1 << levels) - 1
        span = highest - lowest
        position = priority - lowest

        cumulative = 0
        for depth in range(levels):
            band_width = span * (1 << depth) // total_weight
            cumulative += band_width
            if position < cumulative or depth == levels - 1:
                return depth

        return levels - 1

    def rebalance(self, context: RebalanceContext) -> None:
        priority = self.roll_priority(context)

        # State from before this insertion.
        node_count = self.inserted_count
        lowest = self.lowest_priority
        highest = self.highest_priority

        target = (
            0
            if lowest is None
            else self.target_depth(
                priority, lowest, highest, node_count, context.stats.insertion_depth
            )
        )

        # Choose against the PREVIOUS interval; otherwise out-of-range cases
        # become unreachable after incorporating this priority into the extrema.
        self.inserted_count += 1
        if lowest is None or priority < lowest:
            lowest = priority
        if highest is None or priority > highest:
            highest = priority
        self.lowest_priority = lowest
        self.highest_priority = highest

        context.stats.priority = priority

        # A sampled level below this leaf is unreachable by upward rotations.
        # Stay at the insertion depth rather than moving the leaf downward.
        target = min(target, context.stats.insertion_depth)
        if target == context.stats.insertion_depth:
            return

        node = context.inserted
        # Each promotion reduces this leaf's depth by exactly one. Repeated
        # parent walks here would add quadratic work to a long promotion.
        for _ in range(context.stats.insertion_depth - target):
            context.promote(node, distance=0)
