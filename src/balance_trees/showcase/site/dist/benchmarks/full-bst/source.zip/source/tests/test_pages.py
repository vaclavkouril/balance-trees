import re
import tempfile
import unittest
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse

from balance_trees.showcase.build import (
    ENGINE_META,
    PUBLIC_DOCUMENTS,
    PUBLIC_PAGES,
    build_site,
    catalog_source,
)
from balance_trees.showcase.server import STATIC

REPORT_PAGES = ("benchmarks/index.html", "benchmarks/geometric-native/index.html")


class AssetReferences(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self.engine = None

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "meta" and attrs.get("name") == "rotation-lab-engine":
            self.engine = attrs.get("content")
        for name in ("src", "href"):
            value = attrs.get(name, "")
            if value and not value.startswith(("#", "data:", "https:")):
                self.links.append(value)


class PagesBuildTests(unittest.TestCase):
    def test_local_strategy_catalog_matches_factory_metadata(self):
        self.assertEqual((STATIC / "catalog.mjs").read_text(), catalog_source())

    def test_result_pages_and_graphs_are_self_contained(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = build_site(Path(temporary) / "website")
            for filename in (*PUBLIC_PAGES, *REPORT_PAGES):
                page = AssetReferences()
                page.feed((output / filename).read_text())
                for reference in page.links:
                    self.assertTrue(
                        (output / filename).parent.joinpath(reference).is_file(),
                        reference,
                    )

    def test_public_build_excludes_historical_reports_and_their_downloads(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = build_site(Path(temporary) / "website")
            self.assertEqual(
                {path.name for path in output.glob("*.html")}, set(PUBLIC_PAGES)
            )
            self.assertEqual(
                {path.name for path in output.iterdir() if path.is_dir()},
                {"benchmarks"},
            )
            self.assertFalse(any(STATIC.glob("*results*")))
            self.assertIn(
                "Target strategy benchmark report",
                (output / "benchmarks/index.html").read_text(),
            )
            self.assertTrue((output / "benchmarks/source.zip").is_file())
            self.assertIn(
                "C++ geometric probability comparison",
                (output / "benchmarks/geometric-native/index.html").read_text(),
            )
            self.assertTrue(
                (output / "benchmarks/geometric-native/source.zip").is_file()
            )

    def test_staged_assets_resolve_under_a_github_project_path(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = build_site(Path(temporary) / "website")
            page = AssetReferences()
            page.feed((output / "index.html").read_text())
            self.assertEqual(page.engine, "browser")
            self.assertTrue((output / ".nojekyll").is_file())
            base = "https://example.github.io/experimental-balance-trees/"
            for filename in (*PUBLIC_PAGES, *REPORT_PAGES):
                page = AssetReferences()
                page.feed((output / filename).read_text())
                for reference in page.links:
                    url = urlparse(urljoin(base + filename, reference))
                    self.assertTrue(url.path.startswith("/experimental-balance-trees/"))
                    relative = url.path.removeprefix("/experimental-balance-trees/")
                    self.assertTrue((output / relative).exists(), reference)
            for module in output.glob("*.mjs"):
                for reference in re.findall(
                    r"from\s+['\"]([^'\"]+)['\"]", module.read_text()
                ):
                    url = urlparse(urljoin(base + module.name, reference))
                    relative = url.path.removeprefix("/experimental-balance-trees/")
                    self.assertTrue((output / relative).is_file(), reference)

    def test_published_proof_matches_the_source_pdf(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = build_site(Path(temporary) / "website")
            for filename in PUBLIC_DOCUMENTS:
                with self.subTest(filename=filename):
                    source = (
                        Path(__file__).resolve().parents[1] / "docs/proofs" / filename
                    )
                    self.assertEqual(
                        (output / filename).read_bytes(), source.read_bytes()
                    )

    def test_public_build_does_not_change_local_mode_or_copy_site_metadata(self):
        original = (STATIC / "index.html").read_bytes()
        with tempfile.TemporaryDirectory() as temporary:
            output = build_site(Path(temporary) / "website")
            self.assertNotIn(ENGINE_META, (output / "index.html").read_text())
            self.assertFalse((output / ".openai").exists())
            self.assertFalse((output / ".git").exists())
        self.assertEqual((STATIC / "index.html").read_bytes(), original)
        self.assertIn(ENGINE_META, original.decode())

    def test_existing_destination_is_preserved(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary)
            marker = output / "keep.txt"
            marker.write_text("original")
            with self.assertRaises(FileExistsError):
                build_site(output)
            self.assertEqual(list(output.iterdir()), [marker])
            self.assertEqual(marker.read_text(), "original")

    def test_destination_cannot_overlap_the_website_source(self):
        for output in (STATIC, STATIC.parent, STATIC / "nested"):
            with self.subTest(output=output), self.assertRaises(ValueError):
                build_site(output)
